.. include for modules that don't work on WASM

.. availability:: not Emscripten, not WASI.

   This module does not work or is not available on WebAssembly platforms
   ``wasm32-emscripten`` and ``wasm32-wasi``. See
   :ref:`wasm-availability` for more information.
